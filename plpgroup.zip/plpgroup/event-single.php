<?php include 'includes/header.php'; ?>
<div class="container-wrapper">


<?php include 'includes/navigation.php'; ?>

<!--banner area-->
<div class="section banner-page" data-background="imgs/bunner-single.jpg" style="background-image: url(&quot;imgs/bunner.jpg&quot;);">
		<div class="content-wrap pos-relative">
			<div class="d-flex justify-content-center bd-highlight mb-3">
				<div class="title-page">Events Details</div>
			</div>
			<div class="d-flex justify-content-center bd-highlight mb-3">
			    <nav aria-label="breadcrumb">
				  <ol class="breadcrumb ">
				    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
				    <li class="breadcrumb-item active" aria-current="page">Events Detail</li>
				  </ol>
				</nav>
		  	</div>
		</div>
	</div>
<!--content-->
<div class="content-wrap">
			<div class="contain">

				<div class="row">
					<?php
					if(isset($_GET['event'])){
						$e_id =sanitize($_GET['event']);

						$query="SELECT * FROM events WHERE id=$e_id";
						$result = $connection->query($query);
					}
					else{
						header("Location: index.php");
					}

					?>
					<?php
							while($row = mysqli_fetch_assoc($result)){
								$event_id = $row['id'];
							  $event_title = $row['title'];
							  $event_date =  date('F-d-Y ', strtotime($row['event_date']));
							  $event_date = explode('-', $event_date);
								$month = $event_date[0];
							  $day   = $event_date[1];
							  $year  = $event_date[2];

							  $stime = $row['start_time'];
							  $etime = $row['end_time'];
							  $location = $row['venue_location'];
								$discrition=$row['event_description'];
								$image=$row['event_poster'];

					?>


					<div class="col-sm-8 col-md-8">

						<div class="img-date">
							<div class="meta-date">
								<div class="date"><?=$day;?></div>
								<div class="month"><?=$month;?></div>
							</div>
							<img src="admin/<?=$image;?>" alt="" class="img-fluid">
						</div>

						<div class="spacer-10"></div>

						<h2 class="color-secondary"><?=$event_title;?></h2>

						<div class="meta">
							<span class="date"><i class="fa fa-clock-o"></i>  <?=$stime;?> - <?=$etime;?></span>
							<span class="location"><i class="fa fa-map-marker"> </i> <?=$location;?></span>
						</div>

						<div class="spacer-30"></div>

						<p class="uk18 color-secondary"><?=$discrition;?></p>


						<div class="spacer-10"></div>


					</div>
					<?php
					  }


					 ?>

					<div class="col-sm-4 col-md-4">
						<div class="promo-ads" data-background="images/banner-ads.jpg" style="background-image: url(&quot;images/banner-ads.jpg&quot;);">
							<div class="content font__color-white">
								<i class="fa fa-bullhorn"></i>
								<h4 class="title">Become a Volunteer</h4>
								<p class="uk16">“We make a living by what we get, but we make a life by what we give.”</p>
								<p class="font__color-white">―Winston Churchill</p>
								<div class="spacer-30"></div>
								<a href="#" class="btn btn-secondary">JOIN US NOW</a>
							</div>
						</div>

					</div>

				</div>

			</div>
		</div>


	</div>
	<hr>

		  </body>
		</html>
