<?php
define('BASEURL',$_SERVER['DOCUMENT_ROOT'].'/plpgroup/');
define ('ROOT_PATH', realpath(dirname(__FILE__)));
define('DS', DIRECTORY_SEPARATOR);
define('ROOT',dirname(__FILE__));
$url =isset($_SERVER['PATH_INFOR'])? explode('/',ltrim($_SERVER['PATH_INFOR'],'/')):[];
