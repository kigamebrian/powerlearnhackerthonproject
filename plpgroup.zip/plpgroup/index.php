<?php include 'includes/header.php'; ?>
<body>
<?php include 'includes/navigation.php'; ?>
<?php include 'includes/home.php'; ?>


<!-- Page content -->
<div class="wrap">
		<div class="contain">
			<h2 class="content-title">Recent Articles</h2>
			<hr>

          <div class="row">
			<!-- more content still to come here ... -->
        <?php include 'includes/posts.php';?>
         </div>

    </div>


<hr>

</div>
<?php include 'includes/footer.php'?>

</body>
