<?php include 'includes/header.php'; ?>
<div class="container-wrapper">

<?php include 'includes/navigation.php';?>

<!--banner area-->
<div class="section banner-page" data-background="imgs/bunner-single.jpg" style="background-image: url(&quot;imgs/bunner.jpg&quot;);">
		<div class="content-wrap pos-relative">
			<div class="d-flex justify-content-center bd-highlight mb-3">
				<div class="title-page">Gallery</div>
			</div>
			<div class="d-flex justify-content-center bd-highlight mb-3">
			    <nav aria-label="breadcrumb">
				  <ol class="breadcrumb ">
				    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
				    <li class="breadcrumb-item active" aria-current="page">Gallery</li>
				  </ol>
				</nav>
		  	</div>
		</div>
	</div>
  <div class="section">
    <div class="content-wrap">
      <div class="contain">
<?php
if (isset($_GET["page"])) { $page = $_GET["page"]; } else { $page=1; };
$start_from = ($page-1) * 12;
$sql = "SELECT * FROM tbl_album where status='process' ORDER BY albumid DESC LIMIT $start_from, 12";
$rs_result = $connection->query($sql);




####### Fetch Results From Table ########

while ($row = mysqli_fetch_assoc($rs_result))
{
$aimage=$row['image'];
$aid=$row['albumid'];
$aname=$row['name'];
$astatus=$row['status'];

?>
	<div class="pic" style="margin-right:1px;margin-left:1px;margin-top:1px;margin-bottom:1px">
        <?php echo "<img src='admin/acatch/$aimage' class='pic-image' alt='Pic' alt='$aname'>"; ?>
		   <?php echo"<a href='gallery-single.php?id=$aid'>
		    <span class='pic-caption left-to-right'>

		        <p style='color:#FFFFFF;font-size:24px'>$aname</p>
		    </span></a>"?>
		</div>
<?php } ?>
	</section>



		</div>


		<div class="clearfix"></div>


<div class="seeall_div2">
			<!--   NAVIGATION FOR BLOG POST -->
				<div class="blog_navigation">
					<div style="margin-top:20px;margin-left:180px">

                    <?php
$sql = "SELECT COUNT(name) FROM tbl_album";
$rs_result =  $connection->query($sql);
$row = mysqli_fetch_row($rs_result);
$total_records = $row[0];
$total_pages = ceil($total_records / 12);
for ($i=1; $i<=$total_pages; $i++) {
echo "<span class='navigations_items_span'>";
echo "<b>Page </b>";
echo "<a href='gallery.php?page=".$i."' class='navigation_item selected_navigation_item'>".$i."</a>";
echo "</span>";
};
?>


					</div>
				</div>
		</div>
<!----->
</div>
</div>


<!----->

<hr>

</body>
</html>
