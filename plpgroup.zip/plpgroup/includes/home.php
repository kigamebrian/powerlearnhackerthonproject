
<section class="home"></section>
    <div class="container">
      <!-- just to make scrolling effect possible -->
      
      <hr>

    </div>
