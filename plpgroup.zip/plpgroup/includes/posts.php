<?php

$query = "SELECT * FROM posts WHERE post_status='Published' ORDER BY id DESC";
$result =  $connection->query($query);

while ($row = mysqli_fetch_assoc($result)) {

  // code...
  $post_id = $row['id'];
  $post_title = $row['title'];
  $post_author = $row['author'];
  $post_content = $row['post_content'];
  $post_tags = $row['post_tags'];
  $post_status = $row['post_status'];
  $post_image = $row['post_image'];
  $date = $row['post_date'];;
  //$query=mysqli_query($connection, "SELECT * FROM comment WHERE status='Approved' AND post_id=$post_id");
  //$post_comment_count=mysqli_num_rows($query);


  ?>
  <div class="col-sm-4 col-md-4">
    <div class="box-news-1">
      <div class="body">
      <div class="media gbr">
      <a href="blog-single.php?<?=$post_title;?>&post=<?=$post_id;?>" class="blog-entry element-animate" data-animate-effect="fadeIn">
      <img src="admin/<?=$post_image;?>" alt="<?= $post_title;?>" class="img-fluid">
      </div>
      <div class="title">
        <h2><?=$post_title;?></h2>
      </div>
      <div class="meta">
          <span class="author mr-2"><?=$post_author;?></span>&bullet;
          <span class="mr-2"><?=$date;?> </span> &bullet;

        </div>


      </a>
     </div>
    </div>
    </div>



  <?php

}

 ?>
