<?php include 'includes/header.php' ?>
<div class="container-wrapper">

<?php include 'includes/navigation.php' ?>


<!--banner area-->
<div class="section banner-page" data-background="imgs/bunner-single.jpg" style="background-image: url(&quot;imgs/bunner.jpg&quot;);">
		<div class="content-wrap pos-relative">
			<div class="d-flex justify-content-center bd-highlight mb-3">
				<div class="title-page">Events</div>
			</div>
			<div class="d-flex justify-content-center bd-highlight mb-3">
			    <nav aria-label="breadcrumb">
				  <ol class="breadcrumb ">
				    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
				    <li class="breadcrumb-item active" aria-current="page">Events</li>
				  </ol>
				</nav>
		  	</div>
		</div>
	</div>
<div class="section">
  <div class="content-wrap">
    <div class="contain">
      <div class="row">
      <?php include 'includes/event_post.php'; ?>

      </div>

    </div>

  </div>
</div>



</div>
<br>
<hr>

  </body>
</html>
