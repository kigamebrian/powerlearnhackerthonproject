<?php include 'includes/header.php';
include 'includes/navigation.php';
if(!is_logged_in()){
  login_error_redirect();
}
if(!has_permission('Admin')){
  permission_error_redirect('index.php');
}
?>
<style>.navigation_item{
		padding: 0px 5px;
		background: #fff;
		text-decoration: none;

		color: #e3e3e3 !important;
		font-size: 12px;
		border: 2px solid #e3e3e3;
		border-radius: 1px;
		-webkit-transition: all 0.2s linear;
		-moz-transition: all 0.2s linear;
		-ms-transition: all 0.2s linear;
		-o-transition: all 0.2s linear;
	}
	.navigation_item:hover,.selected_navigation_item{
		border: 2px solid #2A6496;
		border-radius: 2px;
		color: #2A6496 !important;
		background: #fff;
	}
	</style>
<div id="wrapper">

	<!-- Navigation -->


	<div id="page-wrapper">

		<div class="container-fluid">

			<!-- Page Heading -->
			<div class="row">

					<h1 class="page-header text-center">
						Welcome to the Administration Panel
					</h1>

			  <div class="col-lg-12">
                    <h2 class="page-header">All Albums</h2>
                </div>

                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                         NONO Album Control panel
                        </div>
                        <div class="panel-body">
                           <div class="table-responsive table-bordered">
                           <?php

if (isset($_GET["page"])) { $page = $_GET["page"]; } else { $page=1; };
$start_from = ($page-1) * 20;
$sql = "select * from tbl_album where status='process' ORDER BY albumid DESC LIMIT $start_from, 20";
$rs_result = $connection->query($sql);
?>
                                <table class="table">

<thead>
                                        <tr>
                                            <th width="20%">Albumname</th>
                                                                                       <th>Albumdesc</th>

                                            <th>Images</th>
											<th colspan=2 width="18%">Action (Delete & Edit)</th>



                                        </tr>
                                    </thead>

<?php
while ($row = mysqli_fetch_assoc($rs_result)) {
?>

`````````````````````````````````<tbody>
                                        <tr>
                                            <td> <?php echo $row["name"]; ?> </td>
                                                                                        <td><?php echo $row["adesc"]; ?></td>

                                            <td><a href='achangeimage.php?key0=<?php echo  $row["albumid"];?>'><img src="acatch/<?php echo $row["image"]; ?>"  width="100px"/></a></td>
                                           <td><a href='albumdelete.php?key1=<?php echo $row["albumid"]; ?>'>Delete</a> | <a href = 'editalbum.php?key0=<?php echo $row["albumid"]; ?> &key1=<?php echo $row["name"]; ?> &key2=<?php echo $row["adesc"]; ?>&key3=<?php echo $row["image"]; ?> '>Edit</a>

                                        </tr>

																			</tbody>

<?php
};
?>
</table>
<strong>Pages  </strong>

<?php
$sql = "SELECT COUNT(name) FROM tbl_album";
$rs_result = $connection->query($sql);
$row = mysqli_fetch_row($rs_result);
$total_records = $row[0];
$total_pages = ceil($total_records / 20);
for ($i=1; $i<=$total_pages; $i++) {
echo "<a href='viewallalbums.php?page=".$i."' class='navigation_item selected_navigation_item'>".$i."</a> ";
};
?>


                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
<!-- jQuery Version 1.11.0 -->
<script type="text/javascript" src="http://twitter.github.io/bootstrap/assets/js/bootstrap-transition.js"></script>
<script type="text/javascript" src="http://twitter.github.io/bootstrap/assets/js/bootstrap-collapse.js"></script
    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').dataTable();
    });
    </script>

</body>

</html>
