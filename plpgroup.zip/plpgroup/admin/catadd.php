<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/plpgroup/core/init.php';

function add_cat(){
global $connection;
if (isset($_POST['cat_add'])) {
  $event_cat = sanitize($_POST['cat_title']);

  $query = "INSERT INTO categories(cat_title)
  VALUES('$event_cat')";

  $result = mysqli_query($connection, $query);

  if (!$result) {
    die("Could not send data " . mysqli_error($connection));
    }
  else{
    header("Location: add_category.php?event_added");
    $_SESSION['success_flash']='Event updated successfully';
  }


}

}
add_cat();

?>
