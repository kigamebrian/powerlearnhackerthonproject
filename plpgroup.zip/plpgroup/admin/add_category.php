<?php include 'includes/header.php';
if(!is_logged_in()){
  login_error_redirect();
}
if(!has_permission('Admin')){
  permission_error_redirect('index.php');
}


?>
<style type="text/css">


img {
max-width: 100%;
max-height: 100%;
}

</style>
    <div id="wrapper">

        <!-- Navigation -->
       <?php include 'includes/navigation.php'; ?>


        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">

                        <h1 class="page-header text-center">
                            Welcome to the Administration Panel
                        </h1>
					<div class="col-sm-4">
            <?php if (!empty($msg)): ?>
              <div class="alert <?php echo $msg_class ?>" role="alert">
                <?php echo $msg; ?>
              </div>
            <?php endif; ?>

            <h4 class="text-center"> Add Category</h4>
						<form action="catadd.php" method="post">
							<div class="form-group">
								<input type="text" name="cat_title" placeholder=" event category" class="form-control" required="">
							</div>
							<div class="form-group">
								<input type="submit" name="cat_add" value="Add Category" class="btn btn-primary">
							</div>
						</form>

						</div>
               	<div class="col-sm-8">
                  <h4 class="text-center">categories</h4>
               <table class="table table-bordered table-striped table-hover">
                 <thead>
                   <th>#</th>
                   <th>Category</th>

                 </thead>

                 <tbody>
                   <?php show_cat(); ?>
                 </tbody>
               </table>
						</div>
                <!-- /.row -->
            </div>
        </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <script>
        function readURL(input) {
          if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
              $('#imgPlaceholder').attr('src', e.target.result);
            }

            // base64 string conversion
            reader.readAsDataURL(input.files[0]);
          }
        }

        $("#chooseFile").change(function () {
          readURL(this);
        });
    </script>

</body>

</html>
