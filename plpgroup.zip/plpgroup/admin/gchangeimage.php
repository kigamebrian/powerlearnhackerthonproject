<?php include 'includes/header.php';
include 'includes/navigation.php';
if(!is_logged_in()){
  login_error_redirect();
}
if(!has_permission('Admin')){
  permission_error_redirect('index.php');
}
?>
<?php
$mykey1=$_REQUEST['key0'];
$asid2=$_REQUEST['asid2'];
?>
<div id="wrapper">

	<!-- Navigation -->


	<div id="page-wrapper">

		<div class="container-fluid">

			<!-- Page Heading -->
			<div class="row">

					<h1 class="page-header text-center">
						Welcome to the Administration Panel
					</h1>
                <!-- /.col-lg-12 -->
            </div>
            </div>
            <!-- /.row -->
            <script type="application/javascript">
function img_up(){var fup = document.getElementById('upload');var fileName = fup.value;var ext = fileName.substring(fileName.lastIndexOf('.') + 1);if(ext == "JPEG" || ext == "jpeg" || ext == "jpg" || ext == "JPG" || ext== "PNG" ||  ext=="png"){return true;}else{alert("Image format not supported!");fup.focus();return false;}}
</script>
<?php
//echo $user;
if(isset($_POST['submit']))
{

$uploadedfile = $_FILES['upload']['tmp_name'];
$src = imagecreatefromjpeg($uploadedfile);
list($width,$height)=getimagesize($uploadedfile);
$newwidth=($width/$height)*150;
$newheight=150;
$tmp=imagecreatetruecolor($newwidth,$newheight);
imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);
$filename = "gcatch/". $_FILES['upload']['name'];
imagejpeg($tmp,$filename,100);
imagedestroy($src);
imagedestroy($tmp);
	$photo=$_FILES['upload']['name'];
	move_uploaded_file($_FILES["upload"]["tmp_name"],"gupload/".$_FILES["upload"]["name"]);




mysqli_query($connection,"update tbl_gallery set gimages='$photo' where gid = '$mykey1'");
echo "<script>location.href='viewsgimages.php?ids=$asid2'</script>";
$_SESSION['success_flash']='Updated successfully';
//echo " <div class='alert alert-success'>Your New Event Is Successfully Added. <a href='viewallevents.php'>View events</a> |<a href='addevent.php'> Add new events</a></div>";
}

?>

          <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Fill This Form To update Gallery Image
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form action="#" method="post" enctype="multipart/form-data" name="upload">

                                      <div class="form-group">
                                            <label>Album Image</label>
                                            <input type="file" name="upload"  id="upload"/>

                                            <p class="help-block">Example "Recomended Image Size in pixel 400 X 300"</p>
                                        </div>



                                        <button type="submit" class="btn btn-primary" name="submit">Update Image</button>

                                    </form>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
    <!-- /#wrapper -->

    <script type="text/javascript" src="http://twitter.github.io/bootstrap/assets/js/bootstrap-transition.js"></script>
    <script type="text/javascript" src="http://twitter.github.io/bootstrap/assets/js/bootstrap-collapse.js"></script>
        <!-- Page-Level Demo Scripts - Tables - Use for reference -->
</body>
</html>
