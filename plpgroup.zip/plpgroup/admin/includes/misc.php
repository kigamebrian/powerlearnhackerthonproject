<?php

function GetNumberPost(){
  global $connection;
  $query=mysqli_query($connection,"SELECT * FROM posts");
  if(mysqli_num_rows($query)> 0){
    return mysqli_num_rows($query);
  }
  return"0";
}
function GetNumbercomments(){
  global $connection;
  $query=mysqli_query($connection,"SELECT * FROM comment");
  if(mysqli_num_rows($query)> 0){
    return mysqli_num_rows($query);
  }
  return"0";
}
function GetNumberEvents(){
  global $connection;
  $query=mysqli_query($connection,"SELECT * FROM events");
  if(mysqli_num_rows($query)> 0){
    return mysqli_num_rows($query);
  }
  return"0";
}

function GetNumberMessages(){
  global $connection;
  $query=mysqli_query($connection,"SELECT * FROM contact_form_infor");
  if(mysqli_num_rows($query)> 0){
    return mysqli_num_rows($query);
  }
  return"0";
}
