<div class="table-responsive">
  <h4 class="text-center"> Posts</h4>
<table class="table table-bordered table-condensed table-striped">
  <thead>
    <th>Post ID</th>
    <th>Post Title</th>
    <th>Post Author</th>
    <th>Post Status</th>
    <th>Post Image</th>
    <th>Post Content</th>
    <th>Post Date</th>
    <th>Post Tags</th>
    <th>Approve/Unaprove</th>
    <th>Edit</th>
    <th>Delete</th>
  </thead>
  <tbody>
  <?php show_posts(); ?>
  </tbody>
</table>
</div>
