<?php
if(!is_logged_in()){
  login_error_redirect();
}
 $sql = "SELECT * FROM categories";
 $res = mysqli_query($connection, $sql);

 ?>

<div class="container">
<div class="row">
  <h2 class="text-center">Add Post</h2><hr>
  <?php if (!empty($msg)): ?>
    <div class="alert <?php echo $msg_class ?>" role="alert">
      <?php echo $msg; ?>
    </div>
  <?php endif; ?>
  <div class="col-sm-12 col-lg-12">
    <form action="./add_post.php" method="post" enctype="multipart/form-data">
      <div class="form-group col-md-4">
        <label for="">Post title</label>
        <input type="text" name="title" placeholder="Post Title" class="form-control"required>
      </div>
      <div class="form-group col-md-4">
        <label for="">Post Author</label>
        <input type="text" name="author" placeholder="Post Author" class="form-control" value="<?=$username;?>" >
      </div>
      <div class="form-group col-md-12">
        <label for="">Post Content</label>
        <textarea name="content" rows="8" cols="80" class="form-control" id="editor" required></textarea>
      </div>
      <div class="form-group col-md-3">
        <label for="">Post Tags</label>
        <input type="text" name="tags" placeholder="Seperate tags with a comma (,)" class="form-control" required>
      </div>
      <div class="form-group col-md-3">
        <label for="">Post Status</label>
      <select class="form-control" name="status">
        <option value="draft">Draft</option>
        <option value="published">Published</option>
      </select>
      </div>
      <div class="form-group col-md-6">
        <label for="">Post Image</label>
        <input type="file" name="post_image"  class="form-control" required>
      </div>
      <div class="form-group col-md-3">
        <input type="submit" name="publish" value="Publish Post"  class="btn btn-primary">
      </div>
    </form>
  </div>
</div>

</div>
<script>
    CKEDITOR.replace( 'editor' );
  </script>
