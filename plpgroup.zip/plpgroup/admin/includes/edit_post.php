<?php
if(!is_logged_in()){
  login_error_redirect();
}
//get categories
 $sql = "SELECT * FROM categories";
 $res = mysqli_query($connection, $sql);
//get post content id
if(isset($_GET['edit_post']) && $_GET['edit_post'] !== ""){
  $edit_id = $_GET['edit_post'];
  $query=mysqli_query($connection,"SELECT * FROM posts WHERE id=$edit_id");
  if(mysqli_num_rows($query)>0){
    $data =mysqli_fetch_array($query);
    $title =$data['title'];
    $author =$data['author'];
    $content=$data['post_content'];
    $tags =$data['post_tags'];
    $status =$data['post_status'];
    $image =$data['post_image'];


  }else{
    die("Failed");
  }


}else{
    die("Failed");
}
 ?>

<div class="container">
<div class="row">
  <h2 class="text-center">Edit Post</h2><hr>
  <div class="col-sm-12 col-lg-12">
    <form action="posts.php" method="post" enctype="multipart/form-data">
      <div class="form-group col-md-4">
        <label for="">Post title</label>
        <input type="text" name="title" placeholder="Post Title" class="form-control" value="<?=  $title;?>">
      </div>
      <div class="form-group col-md-4">
        <label for="">Post Author</label>
        <input type="text" name="author" placeholder="Post Author" class="form-control" value="<?=$author;?>">
      </div>
      <div class="form-group col-md-12">
        <label for="content">Post Content</label>
        <textarea name="content" rows="8" cols="80" class="form-control" id="editor" value="<?=$title;?>"><?=$content;?></textarea>
      </div>
      <div class="form-group col-md-3">
        <label for="">Post Tags</label>
        <input type="text" name="tags" placeholder="Seperate tags with a comma (,)" class="form-control" value="<?=$tags ;?>">
      </div>
      <div class="form-group col-md-3">
        <label for="">Post Status</label>
      <select class="form-control" name="status">
        <?php
          if($status == "Draft"){
          echo"  <option value='draft'>Draft</option>";
          echo"<option value='published'>Published</option>";
        }else{
          echo"<option value='published'>Published</option>";
          echo "<option value='draft'>Draft</option>";

        }
         ?>
        <option value="draft">Draft</option>
        <option value="published">Published</option>
      </select>
      </div>
      <div class="form-group col-md-6">
        <label for="">Post Image</label>
        <input type="file" name="post_image"  class="form-control">
        <br>
        <input type="text" name="image" value="<?=$image?>" style="display: none;">
        <input type="text" name="editId" value="<?=$edit_id?>" style="display: none;">
        <img src="../<?=$image;?>"style="height:200px;width:auto;" alt="25">
      </div>
      <div class="form-group col-md-3">
        <input type="submit" name="modify" value="Update"  class="btn btn-primary">
      </div>
    </form>
  </div>
</div>

</div>
<script>
    CKEDITOR.replace( 'editor' );
    CKEDITOR.config.allowedContent = true;
  </script>
