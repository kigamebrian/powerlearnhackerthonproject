<?php require_once $_SERVER['DOCUMENT_ROOT'].'/kiggzblog/core/init.php';
if(isset($_POST['signup'])){
  $fname=sanitize($_POST['fname']);
  $lname=sanitize($_POST['lname']);
  $username=sanitize($_POST['uname']);
  $username=sanitize($_POST['uname']);
  $email=sanitize($_POST['email']);
  $password=sanitize($_POST['psw']);
  $confirm=sanitize($_POST['rpsw']);
  $errors =array();
  if($_POST){
    $emailQuery =$connection->query("SELECT * FROM users WHERE email='$email'");
    $emailCount=mysqli_num_rows($emailQuery);

    if($emailCount !=0){
      $errors[]='that email already exists';
    }

    $required=array('fname','lname','email','uname','confirm');
    foreach($required as $f){
      if(empty($_POST[$f])){
        $errors[]='Please fill all fields !';
        break;
      }
    }
    if(strlen($password)<5){
      $errors[] ='Your password is too short !';
    }
    if ($password != $confirm){
      $errors[]='Your password do not match';
    }
    if (!filter_var($email,FILTER_VALIDATE_EMAIL)){
      $errors[] ='enter a valid email';
    }


    if(!empty($errors)){
      echo display_errors($errors);

    }

}else{
  echo 'good';
}
}
