<?php require_once $_SERVER['DOCUMENT_ROOT'].'/kiggzblog/core/init.php';
