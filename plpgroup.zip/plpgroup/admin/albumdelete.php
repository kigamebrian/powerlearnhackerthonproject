<?php

$mykey1=$_REQUEST['key1'];
$status='delete';

include 'includes/header.php';
$connection->query("update tbl_album set status='$status' where albumid = '$mykey1'");
echo "<script>location.href='viewallalbums.php'</script>";
$_SESSION['success_flash']=' Deleted successfully';

?>
