<?php include 'includes/header.php';
if(!is_logged_in()){
  login_error_redirect();
}
if(isset($_GET['delete_post']) && $_GET['delete_post'] !== ''){
  $dlt =$_GET['delete_post'];
  if(delete('posts','id',$dlt)){
    redirect('posts.php?source=');
  }
	die('FAILED');
}
//approve post
if (isset($_GET['approve_post']) &&  $_GET['approve_post'] !==""){
  $app_id =$_GET['approve_post'];
  if(modifyStatus($app_id)){
    redirect('posts.php?source=');
  }else {
    die("Failed");
  }
}
//unapprove
if (isset($_GET['unapprove_post']) &&  $_GET['unapprove_post'] !==""){
  $app_id =$_GET['unapprove_post'];
  if(modifyStatus($app_id)){
    redirect('posts.php?source=');
  }else {
    die("Failed");
  }
}
//update or modify
if(isset($_POST['modify'])){
  $eid= sanitize($_POST['editId']);
  $title =sanitize($_POST['title']);
  $author =sanitize($_POST['author']);
  $content=sanitize($_POST['content']);
  $tags=sanitize($_POST['tags']);
  $status=sanitize($_POST['status']);
  $img =sanitize($_POST['image']);
  $post_image =$_FILES['post_image']['name'];
  $date = date("l d F Y");
  $errors =array();
//  echo "<script>alert('yes')</script>";
//get post-cat // I
$sql = mysqli_query($connection," SELECT  id FROM categories  WHERE title ='$category'");
$record =mysqli_fetch_array($sql);
$post_cat_id =$record['id'];
//check if the user is re pploading new image
if(isset($_FILES['post_image']) && $post_image !== ""){
  $dir ="./imgs/";
  $filename = $_FILES['post_image']['name'];
  $filesize= $_FILES['post_image']['size'];
  $fileTmpName=$_FILES['post_image']['tmp_name'];
  $allowed =['png','jpg','jpeg','gif'];
  $fileExt =explode('.',$filename);
  $fileActExt =strtolower(end($fileExt));
  //check if image is allowed

  if(!in_array($fileActExt, $allowed)){
    $errors[] = 'The file extention must be a png, jpg,jpeg or gif';
  }
  if ($filesize>25000000)
  {
    $errors[]='the file size  must be under 25mb';

}
if(!empty($errors)){
  echo display_errors($errors);
}
else{
  $newImage =uniqid("nono",true).".".$fileActExt;
  $target =$dir. basename($newImage);
  if(move_uploaded_file($fileTmpName,$target)){
    $image=$target;
       }
}
}else{
  $image =$img;
}

$query = mysqli_query($connection,"UPDATE posts  SET title='$title',author='$author',post_content='$content',post_date='$date',post_status='$status',post_tags='$tags', post_image='$image' WHERE id='$eid'");
if($query){
  header("Location: posts.php");
    }else {
      echo "Error: " . $query . "<br>" . $connection->error;
      }
}

?>
<div id="wrapper">

	<!-- Navigation -->
	<?php include 'includes/navigation.php'; ?>


	<div id="page-wrapper">

		<div class="container-fluid">

			<!-- Page Heading -->
			<div class="row">

					<h1 class="page-header text-center">
						Welcome to the Administration Panel
					</h1>


					<?php
						if (isset($_GET['source'])) {
								$source = $_GET['source'];

						switch ($source) {
							case 'add_new':
								include "includes/add_post.php";
								break;
                case 'edit':
                  include "includes/edit_post.php";
                  break;
							default:
								include "includes/view_post.php";
								break;
						}
		}else{
      include "includes/view_post.php";
    }
					 ?>
</div>
				</div>


			</div>

			<!-- /.row -->

		</div>
		<!-- /.container-fluid -->

	</div>
	<!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->

<!-- jQuery -->
<script type="text/javascript" src="http://twitter.github.io/bootstrap/assets/js/bootstrap-transition.js"></script>
<script type="text/javascript" src="http://twitter.github.io/bootstrap/assets/js/bootstrap-collapse.js"></script>

</body>

</html>
