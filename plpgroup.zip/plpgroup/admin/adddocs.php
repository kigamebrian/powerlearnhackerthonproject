<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/plpgroup/core/init.php';

function add_document(){
global $connection;
if(isset($_POST['submit'])){
  $doc_name = $_POST["doc_name"];


  if (isset($_FILES['doc'])) {
    #code
    $myfile = explode(".", $_FILES["doc"]["name"]);
    $tmp_name = $_FILES["doc"]["tmp_name"];
    $newfilename = uniqid($doc_name) . "-" . time() . '.' . end($myfile);

    $location ="docs/$newfilename";
    move_uploaded_file($tmp_name,$location);
    chmod($location, 0777);

  }

  $query =mysqli_query($connection,"INSERT INTO documents(name,path) VALUES('$doc_name','$location')");
  header('Location:index.php');


}
}
add_document();
?>
