<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/plpgroup/core/init.php';
unset($_SESSION['login_user']);
unset(	$_SESSION['loggedin_time'] );
$url = "login.php";
if(isset($_GET["session_expired"])) {
	$url .= "?session_expired=" . $_GET["session_expired"];
}
header("Location:$url");
?>
