<?php
include 'includes/header.php';
if(isset($_SESSION['login_user'])){
  header("Location:index.php");
//echo '<script type="text/javascript"> window.location = "https://www.kigzblog.com/admin"</script>';
 }

$errors= array();
?>
<style type="text/css">
body {
    background-color: #f8f8f8;
}
span {
    color: #095506;
}
</style>

<body style="zoom: 1;">

    <div class="container">
      <div class="row">
                <div class="col-md-4 col-md-offset-4">
                    <div class="login-panel panel panel-default">
                                                <div class="panel-heading">


<?php
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

  if (isset($_POST['email'])) {
    $emailTo=((isset($_POST['email']))?sanitize($_POST['email']):'');
    $emailTo=trim($emailTo);
    $token=sha1($emailTo).dechex(time());

    if(empty($_POST['email'])){
      $errors[]='You must provide email .';
    }
    //validate Email
    if(!filter_var($emailTo,FILTER_VALIDATE_EMAIL)){
      $errors[] ='You must enter a valid email';
    }
    //check if email exists
    $query=$connection->query("SELECT * FROM users WHERE email='$emailTo'");
    $user= mysqli_fetch_assoc($query);
    $userCount =mysqli_num_rows($query);
    if($userCount<1){
      $errors[]="User doesn\'t exist in our databae";
    }
    //check for errors
    if(!empty($errors)){
      echo display_errors($errors);
    }


    else{
      $expFormat = mktime(date("H"), date("i"), date("s"), date("m") ,date("d")+1, date("Y"));
      $expDate = date("Y-m-d H:i:s",$expFormat);
      $query =mysqli_query($connection ,"INSERT INTO  resetpass(token, email,expDate) VALUES ('$token','$emailTo','$expDate')");
      if(!$query){
        exit("Error");
      }
      $mail = new PHPMailer(true);

      try {
          //Server settings                      // Enable verbose debug output
          $mail->isSMTP();                                            // Send using SMTP
          $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
          $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
          $mail->Username   = 'briankigame7@gmail.com';                     // SMTP username
          $mail->Password   = 'Avuova@1993';                               // SMTP password
          $mail->SMTPSecure = 'tls';         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
          $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

          //Recipients
          $mail->setFrom('briankigame7@gmail.com', 'nono.org');
          $mail->addAddress($emailTo);     // Add a recipient
          $mail->addReplyTo('no-reply@gmial.com.com', 'Information');


          // Content
          $url="http://".$_SERVER["HTTP_HOST"].dirname($_SERVER["PHP_SELF"])."/resetPassword.php?token=$token";
          $mail->isHTML(true);                                  // Set email format to HTML
          $mail->Subject = 'Your password reset link';
          $mail->Body    = "<h2>You requested a password reset</h2>
                            Click <a href='$url'>this link</a> to reset your email";
          $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

          $mail->send();
          echo '<p class="bg-success">reset passwordlink has been sent to your email</p>';

      } catch (Exception $e) {
          echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
      }

      }





    }


 ?>
               <p>Enter Email Address To Send Password Link</p>
              </div>

                    <div class="panel-body">
                         <form role="form" action="forgotpass.php" method="post">
                         <fieldset>
                             <div class="form-group">
                                 <input class="form-control" placeholder="email" name="email" type="email" value="<?php echo @$_COOKIE['cid'];?>" autofocus="">
                             </div>

                             <!-- Change this to a button or input when using this as a form -->
                             <input type="submit" class="btn btn-lg btn-success btn-block" name="submit" value="submit email">
                         </fieldset>
                     </form>


                    </div>

                    </div>
                  </div>
                </div>
              </div>
              <div align="center">
              Develop By <a href="https://www.kigzblog.com" target="_blank">&lt;kigz&gt;</a></div>
              <!-- jQuery Version 1.11.0 -->
<script src="js/jquery-1.11.0.js"></script>

        <!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
<script src="js/plugins/metisMenu/metisMenu.min.js"></script>

        <!-- Custom Theme JavaScript -->
<script src="js/sb-admin-2.js"></script>
<script type="text/javascript">
  $("#password").password('toggle');
</script>

</body>
