<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/plpgroup/core/init.php';

function add_Event(){
global $connection;
if (isset($_POST['event_add'])) {
  $event_title = sanitize($_POST['title']);
  $event_description =sanitize($_POST['description']);
  $event_date =$_POST['date'];
  $stime =$_POST['start_time'];
  $etime =$_POST['end_time'];
  $venue =sanitize($_POST['venue']);
  $category =sanitize($_POST['category']);
  $msg = "";
  $msg_class = "";
  if (isset($_FILES['Eimage'])) {
    $image = $_FILES['Eimage']['name'];
    $ImageName = time() . '-' . $_FILES["Eimage"]["name"];
    $target_dir= "eventimgs/";
    $target_file = $target_dir . basename($ImageName);
    $fileType = pathinfo($target_file,PATHINFO_EXTENSION);
    $allowTypes = array('jpg','png','jpeg','gif','pdf');
    if($_FILES['Eimage']['size'] > 200000) {
      $msg = "Image size should not be greated than 200Kb";
      $msg_class = "alert-danger";
    }
    if(file_exists($target_file)) {
      $msg = "File already exists";
      $msg_class = "alert-danger";
    }
    elseif(!in_array($fileType, $allowTypes))
    {
      $error = "Sorry, only JPG, JPEG, PNG, GIF, & PDF files are allowed to upload";
       $msg = "alert-danger";
}
    // Upload image only if no errors
    if (empty($error)) {
      if(move_uploaded_file($_FILES["Eimage"]["tmp_name"],$target_file)) {

      $msg = "Image uploaded and saved ";
      $msg_class = "alert-success";
    } else {
      $msg = "There was an error in the database";
      $msg_class = "alert-danger";
    }
  }
}


  $query = "INSERT INTO events(e_title,	e_description,e_date,e_location,e_starttime,e_endtime,e_poste,e_category)
  VALUES('$event_title','$event_description','$event_date','$stime','$etime','$target_file','$venue','$category ')";

  $result = mysqli_query($connection, $query);

  if (!$result) {
    die("Could not send data " . mysqli_error($connection));
    }
  else{
    header("Location: events.php?event_added");
    $_SESSION['success_flash']='Event updated successfully';
  }


}

}
add_Event();

?>
