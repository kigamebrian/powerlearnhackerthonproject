<?php include 'includes/header.php';
include 'includes/navigation.php';
if(!is_logged_in()){
  login_error_redirect();
}
if(!has_permission('Admin')){
  permission_error_redirect('index.php');
}
?>
<div id="wrapper">

	<!-- Navigation -->


	<div id="page-wrapper">

		<div class="container-fluid">

			<!-- Page Heading -->
			<div class="row">

					<h1 class="page-header text-center">
						Welcome to the Administration Panel
					</h1>

				</div>


			</div>
  <?php
      if (isset($_POST['add_user'])){
        $name=((isset($_POST['name']))?sanitize($_POST['name']):"");
        $username=((isset($_POST['username']))?sanitize($_POST['username']):'');
        $email=((isset($_POST['email']))?sanitize($_POST['email']):'');
        $password=((isset($_POST['password']))?sanitize($_POST['password']):'');
        $confirm=((isset($_POST['confirm']))?sanitize($_POST['confirm']):'');
        $permissions=((isset($_POST['permissions']))?sanitize($_POST['permissions']):'');
        $errors =array();
        if($_POST){
          $uppercase = preg_match('@[A-Z]@', $password);
          $lowercase = preg_match('@[a-z]@', $password);
          $number    = preg_match('@[0-9]@', $password);
          $specialChars = preg_match('@[^\w]@', $password);
          $emailQuery =$connection->query("SELECT * FROM users WHERE email='$email'");
          $emailCount=mysqli_num_rows($emailQuery);

          if($emailCount !=0){
            $errors[]='that email already exists';
          }

          $required=array('name','email','confirm','confirm','permissions');
          foreach($required as $f){
            if(empty($_POST[$f])){
              $errors[]='Please fill all fields !';
              break;
            }
          }
          if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($password) < 8) {
              $errors[]='Password should be at least 8 characters in length and should include at least one upper case letter, one number, and one special character.';
        }
          if ($password != $confirm){
            $errors[]='Your password do not match';
          }
          if (!filter_var($email,FILTER_VALIDATE_EMAIL)){
            $errors[] ='enter a valid email';
          }


          if(!empty($errors)){
            echo display_errors($errors);

          }
          else
          {
            //add user
            $rand =rand(1,3);
            switch($rand){
              case "1";
              $profile_pic="users/profile_pics/deafaults/head_1.png";
              break;
              case "2";
              $profile_pic="users/profile_pics/defaults/head_2.png";
              case "3";
              $profile_pic="users/profile_pics/defaults/head_1.png";
              break;
            }

            $hashed=password_hash($password,PASSWORD_DEFAULT);
            $sql="INSERT INTO  users (full_name,username,email,pasword,profile_pic,permissions) VALUES ('$name','$username','$email','$hashed','$profile_pic','$permissions')";
            if ($connection->query($sql) === TRUE) {
               echo "New record created successfully";
            } else {
              echo "Error: " . $sql . "<br>" . $connection->error;
              }

            $_SESSION['success_flash'] ='User has been added !';
            header('Location:users.php');


          }
        }
      }


        // code...
        ?>
      <h2 class="text-center">Add New User</h2>
      <hr>
      <form  action="Add_users.php" method="post">
        <div class="form-group col-md-6">
          <label for="name">Full Name:</label>
          <input type="text" name="name" id="name" class="form-control" >

        </div>

        <div class="form-group col-md-6">
          <label for="email">Email:</label>
          <input type="email" name="email" id="email" class="form-control" >

        </div>
        <div class="form-group col-md-4">
          <label for="name">Username:</label>
          <input type="text" name="username" id="username" class="form-control" >

        </div>
        <div class="form-group col-md-4">
          <label for="password">Password:</label>
          <input type="password" name="password" id="password" class="form-control" >

        </div>
        <div class="form-group col-md-4">
          <label for="Confirm">Confirm Pasword:</label>
          <input type="password" name="confirm" id="confirm" class="form-control" >

        </div>
        <div class="form-group col-md-4">
          <label for="permissions">Permissions:</label>
          <select class="form-control" name="permissions">
            <option value=""<?=(($permissions =='')?' selected':'');?>></option>
            <option value="editor"<?=(($permissions =='editor')?' selected':'');?>>Editor</option>
            <option value="admin,editor"<?=(($permissions =='admin,editor')?' selected':'');?>>Admin</option>

          </select>
        </div>
        <div class="form-group col-md-4 " style="margin-top: 25px;">
          <a href="users.php" class="btn btn-default">Cancel</a>
          <input type="submit" name="add_user" class="btn btn-primary" value="Add User">
        </div>

      </form>




	</div>
		<!-- /.container-fluid -->

	</div>
	<!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->

<!-- jQuery -->


</body>

</html>
