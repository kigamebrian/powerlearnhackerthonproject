<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/plpgroup/core/init.php';

function add_Image(){
global $connection;
$sql = "select * from tbl_album where albumid='$agid'";
$rs = $connection->query($sql);
$row = mysqli_fetch_assoc($rs);
$aname=$row["name"];
$gid=$agid;
$gname=$aname;
$gdate = date('Y-m-d H:i:s');
$status='process';
$rd=rand();
$errors= array()
if(isset($_FILES['upload1'])){

	foreach($_FILES['upload1']['tmp_name'] as $key => $tmp_name){
		$file_name = $key.$rd.$_FILES['upload1']['name'][$key];
		$file_size =$_FILES['upload1']['size'][$key];
		$file_tmp =$_FILES['upload1']['tmp_name'][$key];
		$file_type=$_FILES['upload1']['type'][$key];

        if($file_size > 2097152){
			$errors[]='File size must be less than 2 MB';
        }

        $desired_dir="gupload";
        if(empty($errors)==true){
            if(is_dir($desired_dir)==false){
                mkdir("$desired_dir", 'gupload');
            }
            if(is_dir("$desired_dir/".$file_name)==false){

$src = imagecreatefromjpeg($tmp_name);
list($width,$height)=getimagesize($tmp_name);
$newwidth=($width/$height)*150;
$newheight=150;
$tmp=imagecreatetruecolor($newwidth,$newheight);
imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);
$rd=rand();
$filename = "gcatch/".$file_name;
imagejpeg($tmp,$filename,100);
imagedestroy($src);
move_uploaded_file($file_tmp,"$desired_dir/".$file_name);
            }else{									// rename the file if another one exist
                $new_dir="$desired_dir/".$file_name.time();
                 rename($file_tmp,$new_dir) ;
            }
			  $query="INSERT into tbl_gallery(`gid`,`aid`,`gname`,`gimages`,`date`,`status`) VALUES('','$gid','$gname','$file_name','$gdate','$status')";
		 mysql_query($query);
        }
		else
		{

		 echo "$errors";
        }
    }
	if(empty($errors)){
	echo " <div class='alert alert-success'>Your Photos Is Successfully Uploded. <a href='viewphotos.php'>View Photos</a> |<a href='addevent.php'> Add new Photos</a></div>";

	}
}
}
add_Image();
?>
