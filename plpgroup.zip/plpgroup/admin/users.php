<?php include 'includes/header.php';
include 'includes/navigation.php';
if(!is_logged_in()){
  login_error_redirect();
}
if(!has_permission('Admin')){
  permission_error_redirect('index.php');
}

?>
<div id="wrapper">

	<!-- Navigation -->


	<div id="page-wrapper">

		<div class="container-fluid">

			<!-- Page Heading -->
			<div class="row">

					<h1 class="page-header text-center">
						Welcome to the Administration Panel
					</h1>

				</div>


			</div>
<?php
if(isset($_GET['delete'])){
  $delete_id =sanitize($_GET['delete']);
  $connection->query ("DELETE FROM users WHERE id ='$delete_id'");
  $_SESSION['success_flash'] ='User has been deleted successfully';
  header('Location:users.php');
}
//$time=date("Y-m-d H:i:s");
$gap=10;
$time=date ("Y-m-d H:i:s", mktime (date("H"),date("i"),date("s")-$gap,date("m"),date("d"),date("Y")));
$userQuery =$connection->query("SELECT * FROM users ORDER BY full_name");
?>
<h2 class="text-center">Users</h2>
<a href="Add_users.php" class="btn btn-success pull-right" id="add-product-btn">Add New User</a><div class="clearfix">

</div>
<hr>
<div id="load_form">
  <table  class="table table-bordered table-striped teble-condensed">
    <thead><th>#</th><th>Delete</th><th>Name</th> <th>Username</th><th>Email</th><th>Last Time Online</th><th>Permissions</th></thead>
    <?php
    $i=1;
    while($user =mysqli_fetch_assoc($userQuery)){
      $status= 'Offline';
      $class="bg-danger";
      if($user['last_login']>$time){
        $status='Online';
        $class="bg-success";
      }

      ?>
    <tr>
      <th scope="row"><?=$i ?></th>
      <td>
        <?php if($user['id'] != $user_data['id'] && $user['permissions']!='Admin'): ?>
          <a href="users.php?delete=<?=$user['id']; ?>" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-remove-sign"></span></a>

        <?php endif; ?>


      </td>
      <td><?=$user['full_name'];?></td>
        <td><?=$user['username'];?></td>
      <td><?=$user['email'];?></td>
      <td><?=pretty_date($user['last_login']); ?></td>
      <td><?=$user['permissions'];?></td>


    </tr>

  <?php
  $i++;
   }
  ?>
  </table>



	</div>
		<!-- /.container-fluid -->

	</div>
	<!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->
<script type="text/javascript" src="http://twitter.github.io/bootstrap/assets/js/bootstrap-transition.js"></script>
<script type="text/javascript" src="http://twitter.github.io/bootstrap/assets/js/bootstrap-collapse.js"></script>

</body>

</html>
