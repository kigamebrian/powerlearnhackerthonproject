<?php
include 'includes/header.php';
$_SESSION['timestamp']=time();
if(isset($_SESSION['login_user'])){
  header("Location:index.php");
//echo '<script type="text/javascript"> window.location = "https://www.kigzblog.com/admin"</script>';
 }

$query ="SELECT * FROM users";
$result=$connection->query($query);
$email=((isset($_POST['email']))?sanitize($_POST['email']):'');
$email=trim($email);
$password=((isset($_POST['password']))?sanitize($_POST['password']):'');
$password=trim($password);
$errors= array();
?>
<style type="text/css">
body {
    background-color: #f8f8f8;
}
span {
    color: #095506;
}
</style>

<body style="zoom: 1;">

    <div class="container">
      <div class="row">
                <div class="col-md-4 col-md-offset-4">
                    <div class="login-panel panel panel-default">
                                                <div class="panel-heading">
                        <?php
                        if($_POST){
                          //form validation
                          if(empty($_POST['email']) || empty($_POST['password'])){
                            $errors[]='You must provide email and pasword.';
                          }
                          //validate Email
                          if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
                            $errors[] ='You must enter a valid email';
                          }
                          if(strlen($password)<5){
                            $errors[]='Password must be at least 10 characters';
                          }
                          //check if email exists
                          $query=$connection->query("SELECT * FROM users WHERE email='$email'");
                          $user= mysqli_fetch_assoc($query);
                          $userCount =mysqli_num_rows($query);
                          if($userCount<1){
                            $errors[]="User doesn\'t exist in our databae";
                          }

                          if(!password_verify($password,$user['pasword'])){
                            $errors[]='Invalid password. Please try again';

                          }

                          //check for errors
                          if(!empty($errors)){
                            echo display_errors($errors);
                          }
                          elseif($_POST['remember']==true)
                            {
                            setcookie("cid",$email,time()+60*60);
                            setcookie("cpass",$password,time()+60*60);
                            $user_id = $user['id'];
                            login($user_id);

                          }

                          else{

                            //log user in
                            $user_id = $user['id'];
                            login($user_id);
                          }

                        }
                        ?>

                        <h3 class="panel-title">Nobility Of <span>Nature</span> org admin Panel Login</h3>
                    </div>

                    <div class="panel-body">
                                            <form role="form" action="login.php" method="post">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" placeholder="email" name="email" type="email" value="<?php echo @$_COOKIE['cid'];?>" autofocus="">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" id="password"  type="password" value="<?php echo @$_COOKIE['cpass'];?>"data-toggle="password">
                                </div>
                                <div class="checkbox">
                                    <label>
                                        <input   name="remember" type="checkbox" value="Remember Me">Remember Me
                                    </label>
                                </div>
                                <!-- Change this to a button or input when using this as a form -->
                                <input type="submit" class="btn btn-lg btn-success btn-block" name="login" value="Login">
                            </fieldset>
                        </form>
                        <p style="text-align:left;">
                              <a href="forgotpass.php" alt="forgot">forgot password</a>
                              <span style="float:right;">
                                      <a href="/nono/index.php" alt="home" class="text-right">Visit Site</a>
                              </span>
                          </p>

                    </div>

                </div>
            </div>
        </div>
    </div>
    <div align="center">
Develop By <a href="https://www.kigzblog.com" target="_blank">&lt;kigz&gt;</a></div>
    <!-- jQuery Version 1.11.0 -->
    <script src="js/jquery-1.11.0.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="js/plugins/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/sb-admin-2.js"></script>

    <script type="text/javascript">
    	$("#password").password('toggle');
    </script>


</body>
