<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/plpgroup/core/init.php';
$query ="SELECT * FROM users";
$result=$connection->query($query);

if(mysqli_num_rows($result) ===0){
  include'create_admin.php';

}
else{
  include'login.php';
}

 ?>
