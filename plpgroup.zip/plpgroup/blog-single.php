<?php include 'includes/header.php' ?>


<div class="container-wrapper">


<?php include 'includes/navigation.php'; ?>


	<a href="#0" class="cd-top cd-is-visible">Top</a>
<div class="section banner-page" data-background="imgs/bunner-single.jpg" style="background-image: url(&quot;imgs/bunner.jpg&quot;);">
		<div class="content-wrap pos-relative">
			<div class="d-flex justify-content-center bd-highlight mb-3">
				<div class="title-page">Blog/News Details</div>
			</div>
			<div class="d-flex justify-content-center bd-highlight mb-3">
			    <nav aria-label="breadcrumb">
				  <ol class="breadcrumb ">
				    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
				    <li class="breadcrumb-item active" aria-current="page">"News Detail"</li>
				  </ol>
				</nav>
		  	</div>
		</div>
	</div>
<br>
<br>
<?php
if(isset($_GET['post'])){
	$p_id =sanitize($_GET['post']);

	$query="SELECT * FROM posts WHERE id=$p_id";
	$result = $connection->query($query);
}
else{
	header("Location: index.php");
}

?>
<?php
		while($row = mysqli_fetch_assoc($result)){
			$p_id = $row['id'];
			$p_title = $row['title'];
			$p_author = $row['author'];
			$p_content = $row['post_content'];
			$p_date = $row['post_date'];
			$p_image = $row['post_image'];
			$p_tags=$row['post_tags']


?>

<div class="section">
		<div class="content-wrap">
			<div class="contain">
				<div class="row">
					<div class="col-sm-3 col-md-3">
						<div class="sidebar-box search-form-wrap">
							<form action="" class="search-form" method="post">
								<div class="form-group">
									<span class="icon fa fa-search"></span>
									<input type="text" name="search" class="form-control" id="searchfor" placeholder="Type a keyword and hit enter">
								</div>
							</form>
						</div>


				<?php include 'includes/sidebar.php';?>
<!--
						<div class="widget widget-archive">
							<div class="widget-title">
								Archive
							</div>
							<select class="form-control">
								<option>April 2017</option>
								<option>March 2017</option>
								<option>February 2017</option>
								<option>January 2017</option>
							</select>
						</div>
-->
						<div class="widget tags">
							<div class="widget-title">
								Tags
							</div>
							<?php include 'includes/tags.php';?>
						</div>


					</div>
					<div class="col-sm-9 col-md-9">
						<div class="single-news">
							<div class="image">
								<img src="admin/<?=$p_image;?>" alt="" class="img-fluid">
							</div>
							<h2 class="blok-title">
								<?=	$p_title;?>						</h2>
							<div class="meta">
								<div class="meta-date"><i class="fa fa-clock-o"></i> <?=$p_date;?></div>
								<div class="meta-author"> Posted by: <a href="#"><?=$p_author;?></a></div>
								<div class="meta-category"> Category: <a href="blog.php">Blog</a>&<a href="blog.php">News</a></div>
								<div class="meta-comment"><i class="fa fa-comment-o"></i> 2 Comments</div>
							</div>
							<br>
							<p><?=$p_content;?></p>
							<p> Share:
								<div id="share"></div>


							</p>
						 </div>
<?php }
 ?>


				<div class="comments-box">
							<h4 class="title-heading">
								<?php
				(isset($_GET['post']))? $post_id=$_GET['post'] :$post_id
				=0;
				$query=mysqli_query($connection, "SELECT * FROM comment WHERE status='Approved' AND post_id=$post_id");
				$num_comment=mysqli_num_rows($query);
				echo $num_comment. " comment(s)";
					?>

								</h4>


							<div class="media1 comment">

									<?php
													if(isset($_GET['post'])){
														$id=$_GET['post'];
													$comment_obj->getAprovedComments($id);
													}
													 ?>




	                        </div>



						</div>

						<div class="leave-comment-box">
							<h4 class="title-heading">Leave Comments</h4>
							<p id="show_message" style="display: none" class="bg-success">comment submited successfully</p>
							<span id="error" style="display: none" class="bg-danger"></span>
							<form action="javascript:void(0)" method"post" class="form-comment"id="ajax-form">
								<input type="hidden" name="post_id" id="post_id" value="<?=$p_id ;?>">
                <input type="hidden" name="post_author" id="post_author" value="<?=$p_author;?>">
								<div class="row">
									<div class="col-xs-12 col-md-6">
										<div class="form-group">
											<input type="text" id="name" name="name" value="" class="inputtext form-control" placeholder="Enter Name">
										</div>
									</div>
									<div class="col-xs-12 col-md-6">
										<div class="form-group">
											<input type="email" id="email" name="email" value="" class="inputtext form-control" placeholder="Enter Email">
										</div>
									</div>

									<div class="col-xs-12 col-md-12">
										<div class="form-group">
											<textarea id="content" name="content" class="inputtext form-control" rows="6" placeholder="Enter Your Message..."></textarea>
										</div>
									</div>
									<div class="col-xs-12 col-md-12">
										<div class="form-group">
											<input type="submit" id="send" name="submit" type="submit" class="btn btn-primary" value="Post Comment">
										</div>
									</div>
								</div>
							</form>

						</div>

					</div>

				</div>

			</div>
		</div>
	</div>





</div>
<?php include 'includes/footer.php'; ?>
<script type="text/javascript" src="https://cdn.jsdelivr.net/jquery.jssocials/1.4.0/jssocials.min.js"></script>
<script type="text/javascript">

$(document).ready(function($){

   // hide messages
   $("#error").hide();
   $("#show_message").hide();

   // on submit...
   $('#ajax-form').submit(function(e){

       e.preventDefault();


       $("#error").hide();

       //name required
       var name = $("input#name").val();
       if(name == ""){
           $("#error").fadeIn().text("Name required.");
           $("input#name").focus();
           return false;
       }

       // email required
       var email = $("input#email").val();
       if(email == ""){
           $("#error").fadeIn().text("Email required");
           $("input#email").focus();
           return false;
       }

       // mobile number required
       var content = $("textarea#content").val();
       if(content == ""){
           $("#error").fadeIn().text("Content is required");
           $("textarea#content").focus();
           return false;
       }
       //var postid =$("input#post_id").val();

       $.ajax({
           type:"POST",
           url: "result.php",
           data: $(this).serialize(), // get all form field value in serialize form
           success: function(){
             $("#show_message").fadeIn();
             $('#ajax-form')[0].reset();
             //$("#ajax-form").fadeOut();
           }
       });
   });

   return false;
   });

$("#share").jsSocials({
	 shares: ["email", "twitter", "facebook", "googleplus", "linkedin", "pinterest", "stumbleupon", "whatsapp"]
	});
	$('#searchfor').keyup(function(){
         var page = $('#all_text');
         var pageText = page.text().replace("<span>","").replace("</span>");
         var searchedText = $('#searchfor').val();
         var theRegEx = new RegExp("("+searchedText+")", "igm");
         var newHtml = pageText.replace(theRegEx ,"<span>$1</span>");
         page.html(newHtml);
    });
</script>
</body>
</body>
